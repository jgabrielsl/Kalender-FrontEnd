import './Body.css';
import '../../views/Home/home.css';
import '../../views/Home/responsive-home.css';

const Body = () => {
  return (
     <main className="container">
       <hr className="linha__horizontal" />
     </main>
  );
};

export default Body;

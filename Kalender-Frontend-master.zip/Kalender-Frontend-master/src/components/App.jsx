import './App.css'
import Rotas from '../route/rotas'

function App() {
  return (
    <Rotas />
  )
}
export default App
